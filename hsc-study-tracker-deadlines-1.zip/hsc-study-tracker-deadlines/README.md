# HSC Mission Plus

Open index.html in a browser.

Features added: per-subject chapter/topic study logs (topic name, duration in minutes, start time, finish time), delete log, and a user-editable Chorchha app/topic URL per subject. Data is saved in this browser on this device. Export/backup cloud sync for these new logs is not configured; keep a browser backup if the records are important.

To use your Chorchha link, paste the exact app or topic URL into the field under the relevant subject and tap “লিংক সেভ”.
